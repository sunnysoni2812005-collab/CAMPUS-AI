import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, animate, motion, useMotionValue, useTransform } from "framer-motion";
import { ArrowUp, Camera, Check, ChevronRight, ClipboardList, Crosshair, LayoutDashboard, MapPin, Sparkles, X, Zap } from "lucide-react";
import { CATS, STATUS_META, SEED, analyze, timeAgo, type Category, type Complaint, type Status } from "./lib";

type Tab = "report" | "track" | "staff";

const Asterisk = ({ size = 40, spin = true }: { size?: number; spin?: boolean }) => (
  <svg width={size} height={size} viewBox="0 0 40 40" className={spin ? "spin-slow" : ""}>
    {Array.from({ length: 12 }).map((_, i) => (
      <rect key={i} x="18.2" y="2" width="3.6" height="14" rx="1.8" fill="#fb925f" transform={`rotate(${i * 30} 20 20)`} />
    ))}
  </svg>
);

function Counter({ to }: { to: number }) {
  const mv = useMotionValue(0);
  const rounded = useTransform(mv, (v) => Math.round(v));
  useEffect(() => {
    const c = animate(mv, to, { duration: 1.1, ease: "easeOut" });
    return () => c.stop();
  }, [to, mv]);
  return <motion.span>{rounded}</motion.span>;
}

function StatusBadge({ s }: { s: Status }) {
  const m = STATUS_META[s];
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium ${m.color}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${m.dot} ${s !== "resolved" ? "animate-pulse" : ""}`} />
      {m.label}
    </span>
  );
}

const PRI: Record<string, string> = {
  high: "text-rose-300 bg-rose-500/10 border-rose-400/30",
  medium: "text-amber-300 bg-amber-500/10 border-amber-400/30",
  low: "text-zinc-300 bg-zinc-500/10 border-zinc-400/30",
};

export default function App() {
  const [tab, setTab] = useState<Tab>("report");
  const [items, setItems] = useState<Complaint[]>(() => {
    try {
      const s = localStorage.getItem("campusai-v1");
      return s ? JSON.parse(s) : SEED;
    } catch {
      return SEED;
    }
  });
  useEffect(() => {
    try {
      localStorage.setItem("campusai-v1", JSON.stringify(items));
    } catch {
      /* quota */
    }
  }, [items]);

  const [lastId, setLastId] = useState<string | null>(null);

  const add = (c: Complaint) => {
    setItems((p) => [c, ...p]);
    setLastId(c.id);
  };
  const setStatus = (id: string, status: Status) =>
    setItems((p) => p.map((c) => (c.id === id ? { ...c, status, timeline: [...c.timeline, { status, at: Date.now() }] } : c)));

  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: "report", label: "Report", icon: <Sparkles size={15} /> },
    { id: "track", label: "Track", icon: <ClipboardList size={15} /> },
    { id: "staff", label: "Staff", icon: <LayoutDashboard size={15} /> },
  ];

  return (
    <div className="noise relative min-h-screen overflow-x-hidden bg-[#0b0a09]">
      {/* ambient blobs */}
      <div className="pointer-events-none fixed inset-0 -z-0">
        <div className="blob1 absolute -left-32 -top-32 h-[480px] w-[480px] rounded-full bg-orange-500/25 blur-[120px]" />
        <div className="blob2 absolute -right-40 top-1/3 h-[520px] w-[520px] rounded-full bg-fuchsia-600/15 blur-[130px]" />
        <div className="blob1 absolute bottom-[-200px] left-1/3 h-[420px] w-[420px] rounded-full bg-sky-500/15 blur-[120px]" />
      </div>

      <header className="sticky top-0 z-30 border-b border-white/5 bg-[#0b0a09]/60 backdrop-blur-xl">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-2.5">
            <Asterisk size={26} />
            <span className="font-display text-xl font-semibold tracking-tight">
              Campus<span className="text-orange-400">AI</span>
            </span>
          </div>
          <nav className="relative flex rounded-full border border-white/10 bg-white/5 p-1">
            {tabs.map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className="relative z-10 flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-sm font-medium transition-colors sm:px-4"
                style={{ color: tab === t.id ? "#1a0f08" : "#cfc6bd" }}
              >
                {tab === t.id && (
                  <motion.span layoutId="pill" className="absolute inset-0 -z-10 rounded-full bg-orange-400" transition={{ type: "spring", stiffness: 420, damping: 32 }} />
                )}
                {t.icon}
                {t.label}
                {t.id === "track" && <span className="rounded-full bg-black/20 px-1.5 text-[10px]">{items.length}</span>}
              </button>
            ))}
          </nav>
        </div>
      </header>

      <main className="relative z-10 mx-auto max-w-5xl px-4 pb-24 pt-10">
        <AnimatePresence mode="wait">
          <motion.div key={tab} initial={{ opacity: 0, y: 18, filter: "blur(6px)" }} animate={{ opacity: 1, y: 0, filter: "blur(0px)" }} exit={{ opacity: 0, y: -12, filter: "blur(6px)" }} transition={{ duration: 0.35 }}>
            {tab === "report" && <Report onAdd={add} onTrack={() => setTab("track")} count={items.length} />}
            {tab === "track" && <Track items={items} highlight={lastId} />}
            {tab === "staff" && <Staff items={items} setStatus={setStatus} />}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}

/* ───────────────────────── REPORT ───────────────────────── */

const STEPS = ["Reading your description", "Scanning the photo", "Classifying severity", "Routing to the right person"];

function Report({ onAdd, onTrack, count }: { onAdd: (c: Complaint) => void; onTrack: () => void; count: number }) {
  const [cat, setCat] = useState<Category | null>(null);
  const [photo, setPhoto] = useState<string>();
  const [loc, setLoc] = useState("");
  const [desc, setDesc] = useState("");
  const [locating, setLocating] = useState(false);
  const [phase, setPhase] = useState<"form" | "analyzing" | "done">("form");
  const [step, setStep] = useState(0);
  const [result, setResult] = useState<Complaint | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const ready = cat && loc.trim() && desc.trim().length > 5;

  const onFile = (f?: File) => {
    if (!f) return;
    const img = new Image();
    const url = URL.createObjectURL(f);
    img.onload = () => {
      const max = 640;
      const r = Math.min(1, max / Math.max(img.width, img.height));
      const cv = document.createElement("canvas");
      cv.width = img.width * r;
      cv.height = img.height * r;
      cv.getContext("2d")!.drawImage(img, 0, 0, cv.width, cv.height);
      setPhoto(cv.toDataURL("image/jpeg", 0.7));
      URL.revokeObjectURL(url);
    };
    img.src = url;
  };

  const locate = () => {
    if (!navigator.geolocation) return setLoc("Campus (location unavailable)");
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (p) => {
        setLoc(`GPS ${p.coords.latitude.toFixed(4)}, ${p.coords.longitude.toFixed(4)}`);
        setLocating(false);
      },
      () => {
        setLoc("Main Campus");
        setLocating(false);
      },
      { timeout: 6000 }
    );
  };

  const submit = () => {
    if (!ready || !cat) return;
    setPhase("analyzing");
    setStep(0);
    const t = [700, 1400, 2100, 2800].map((ms, i) => setTimeout(() => setStep(i + 1), ms));
    setTimeout(() => {
      const c: Complaint = {
        id: `CMP-${1043 + count - 3 + Math.floor(Math.random() * 3)}`,
        category: cat, location: loc, description: desc, photo, createdAt: Date.now(), status: "pending",
        assignee: CATS[cat].staff, ai: analyze(cat, desc, !!photo), timeline: [{ status: "pending", at: Date.now() }],
      };
      c.id = `CMP-${Math.floor(1100 + Math.random() * 900)}`;
      onAdd(c);
      setResult(c);
      setPhase("done");
    }, 3300);
    return () => t.forEach(clearTimeout);
  };

  const reset = () => {
    setCat(null); setPhoto(undefined); setLoc(""); setDesc(""); setResult(null); setPhase("form");
  };

  return (
    <div>
      <div className="mb-10 text-center">
        <motion.div initial={{ scale: 0, rotate: -180 }} animate={{ scale: 1, rotate: 0 }} transition={{ type: "spring", stiffness: 140, damping: 14 }} className="mb-3 inline-flex">
          <Asterisk size={54} />
        </motion.div>
        <h1 className="font-display text-5xl font-semibold leading-[1.05] tracking-tight sm:text-7xl">
          <span className="shimmer-text">Here we go!</span>
        </h1>
        <p className="mx-auto mt-4 max-w-xl text-balance text-zinc-400">
          Report an issue in 3 taps. AI reads it, sets the priority and sends it straight to the right person. <span className="text-zinc-200">Nothing gets lost in paperwork.</span>
        </p>
      </div>

      <div className="relative">
        <AnimatePresence mode="wait">
          {phase === "form" && (
            <motion.div key="form" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.97 }} className="glass rounded-[28px] p-5 shadow-2xl shadow-black/40 sm:p-7">
              <p className="mb-3 text-xs font-semibold uppercase tracking-widest text-zinc-500">1 · Category</p>
              <div className="grid gap-3 sm:grid-cols-3">
                {(Object.keys(CATS) as Category[]).map((k, i) => {
                  const on = cat === k;
                  return (
                    <motion.button
                      key={k}
                      initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.08 * i }}
                      whileHover={{ y: -4 }} whileTap={{ scale: 0.97 }}
                      onClick={() => setCat(k)}
                      className={`relative overflow-hidden rounded-2xl border p-4 text-left transition-colors ${on ? "border-orange-400/70" : "border-white/10 hover:border-white/25"}`}
                    >
                      <div className={`absolute inset-0 bg-gradient-to-br ${CATS[k].grad} transition-opacity ${on ? "opacity-100" : "opacity-40"}`} />
                      <div className="relative">
                        <div className="flex items-center justify-between">
                          <span className="text-2xl">{CATS[k].emoji}</span>
                          <AnimatePresence>
                            {on && (
                              <motion.span initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }} className="flex h-5 w-5 items-center justify-center rounded-full bg-orange-400 text-black">
                                <Check size={12} strokeWidth={3} />
                              </motion.span>
                            )}
                          </AnimatePresence>
                        </div>
                        <p className="mt-2 font-semibold">{CATS[k].label}</p>
                        <p className="mt-0.5 text-xs text-zinc-400">{CATS[k].blurb}</p>
                        <p className="mt-3 flex items-center gap-1 text-[11px] text-orange-300/90"><ChevronRight size={12} /> goes to {CATS[k].staff}</p>
                      </div>
                    </motion.button>
                  );
                })}
              </div>

              <div className="mt-7 grid gap-5 sm:grid-cols-[220px_1fr]">
                <div>
                  <p className="mb-3 text-xs font-semibold uppercase tracking-widest text-zinc-500">2 · Photo</p>
                  <input ref={fileRef} type="file" accept="image/*" capture="environment" hidden onChange={(e) => onFile(e.target.files?.[0])} />
                  <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} onClick={() => fileRef.current?.click()}
                    className="group relative flex h-44 w-full items-center justify-center overflow-hidden rounded-2xl border border-dashed border-white/20 bg-white/[0.03] hover:border-orange-400/60">
                    {photo ? (
                      <>
                        <img src={photo} alt="" className="h-full w-full object-cover" />
                        <span onClick={(e) => { e.stopPropagation(); setPhoto(undefined); }} className="absolute right-2 top-2 rounded-full bg-black/60 p-1.5 hover:bg-black"><X size={14} /></span>
                      </>
                    ) : (
                      <span className="flex flex-col items-center gap-2 text-sm text-zinc-400 group-hover:text-orange-300">
                        <span className="rounded-full bg-white/5 p-3"><Camera size={22} /></span>
                        Add photo
                      </span>
                    )}
                  </motion.button>
                </div>
                <div className="flex flex-col">
                  <p className="mb-3 text-xs font-semibold uppercase tracking-widest text-zinc-500">3 · Location & details</p>
                  <div className="relative">
                    <MapPin size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-500" />
                    <input value={loc} onChange={(e) => setLoc(e.target.value)} placeholder="e.g. Block B, Room 204"
                      className="w-full rounded-xl border border-white/10 bg-white/5 py-3 pl-10 pr-12 text-sm outline-none transition focus:border-orange-400/70 focus:bg-white/[0.08]" />
                    <button onClick={locate} title="Use my location" className="absolute right-2 top-1/2 -translate-y-1/2 rounded-lg p-2 text-orange-300 hover:bg-white/10">
                      <Crosshair size={16} className={locating ? "animate-spin" : ""} />
                    </button>
                  </div>
                  <textarea value={desc} onChange={(e) => setDesc(e.target.value)} rows={4} placeholder="Describe the problem…"
                    className="mt-3 w-full flex-1 resize-none rounded-xl border border-white/10 bg-white/5 p-3.5 text-sm outline-none transition focus:border-orange-400/70 focus:bg-white/[0.08]" />
                </div>
              </div>

              <div className="mt-6 flex items-center justify-between gap-4">
                <p className="hidden text-xs text-zinc-500 sm:block">{cat ? <>Will be sent to <b className="text-orange-300">{CATS[cat].staff}</b></> : "Pick a category to continue"}</p>
                <motion.button
                  onClick={submit} disabled={!ready}
                  whileHover={ready ? { scale: 1.04 } : {}} whileTap={ready ? { scale: 0.94 } : {}}
                  className={`ml-auto flex items-center gap-2 rounded-2xl px-6 py-3 text-sm font-semibold transition ${ready ? "pulse-ring bg-gradient-to-br from-orange-300 to-orange-500 text-[#1a0f08]" : "cursor-not-allowed bg-white/10 text-zinc-500"}`}
                >
                  Submit complaint <ArrowUp size={16} strokeWidth={2.6} />
                </motion.button>
              </div>
            </motion.div>
          )}

          {phase === "analyzing" && (
            <motion.div key="an" initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} className="glass rounded-[28px] p-8 sm:p-10">
              <div className="grid items-center gap-8 sm:grid-cols-2">
                <div className="relative mx-auto aspect-square w-full max-w-[280px] overflow-hidden rounded-3xl border border-orange-400/30 bg-black/40">
                  {photo ? <img src={photo} alt="" className="h-full w-full object-cover opacity-80" /> : <div className="flex h-full items-center justify-center"><Asterisk size={90} /></div>}
                  <div className="scanline" />
                  <div className="absolute inset-0 bg-gradient-to-t from-orange-500/20 to-transparent" />
                </div>
                <div>
                  <p className="mb-4 flex items-center gap-2 font-display text-2xl font-semibold"><Zap className="text-orange-400" size={22} /> AI is analysing…</p>
                  <ul className="space-y-3">
                    {STEPS.map((s, i) => (
                      <motion.li key={s} initial={{ opacity: 0, x: -14 }} animate={{ opacity: step >= i ? 1 : 0.3, x: 0 }} transition={{ delay: i * 0.1 }} className="flex items-center gap-3 text-sm">
                        <span className={`flex h-6 w-6 items-center justify-center rounded-full border ${step > i ? "border-orange-400 bg-orange-400 text-black" : "border-white/20"}`}>
                          {step > i ? <motion.span initial={{ scale: 0 }} animate={{ scale: 1 }}><Check size={13} strokeWidth={3} /></motion.span> : step === i ? <span className="h-2 w-2 animate-ping rounded-full bg-orange-400" /> : null}
                        </span>
                        {s}
                      </motion.li>
                    ))}
                  </ul>
                  <div className="mt-6 h-1.5 overflow-hidden rounded-full bg-white/10">
                    <motion.div className="h-full bg-gradient-to-r from-orange-300 to-orange-500" initial={{ width: 0 }} animate={{ width: "100%" }} transition={{ duration: 3.2, ease: "easeInOut" }} />
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {phase === "done" && result && (
            <motion.div key="done" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ type: "spring", damping: 16 }} className="glass relative overflow-hidden rounded-[28px] p-8 text-center sm:p-10">
              {Array.from({ length: 18 }).map((_, i) => (
                <motion.span key={i} className="absolute left-1/2 top-24 h-2 w-2 rounded-full" style={{ background: ["#fb925f", "#fbbf24", "#34d399", "#60a5fa", "#f472b6"][i % 5] }}
                  initial={{ x: 0, y: 0, opacity: 1 }} animate={{ x: Math.cos(i * 20) * 240, y: Math.sin(i * 20) * 160 - 40, opacity: 0, scale: 0.4 }} transition={{ duration: 1.3, ease: "easeOut" }} />
              ))}
              <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", delay: 0.15, stiffness: 200 }} className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-400 text-black">
                <Check size={34} strokeWidth={3} />
              </motion.div>
              <h2 className="mt-5 font-display text-3xl font-semibold">Complaint sent!</h2>
              <p className="mt-1 text-sm text-zinc-400">ID <span className="font-mono text-zinc-200">{result.id}</span></p>

              <div className="mx-auto mt-6 grid max-w-xl gap-3 text-left sm:grid-cols-3">
                {[
                  ["Routed to", result.assignee],
                  ["AI priority", result.ai.priority.toUpperCase()],
                  ["Expected fix", result.ai.eta],
                ].map(([k, v], i) => (
                  <motion.div key={k} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 + i * 0.1 }} className="rounded-2xl border border-white/10 bg-white/5 p-4">
                    <p className="text-[11px] uppercase tracking-widest text-zinc-500">{k}</p>
                    <p className="mt-1 font-semibold">{v}</p>
                  </motion.div>
                ))}
              </div>
              <p className="mx-auto mt-5 max-w-md text-sm italic text-zinc-400">“{result.ai.summary}” · {result.ai.confidence}% confidence</p>
              <div className="mt-7 flex justify-center gap-3">
                <button onClick={onTrack} className="rounded-xl bg-orange-400 px-5 py-2.5 text-sm font-semibold text-black hover:bg-orange-300">Track status</button>
                <button onClick={reset} className="rounded-xl border border-white/15 px-5 py-2.5 text-sm hover:bg-white/10">Report another</button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

/* ───────────────────────── TRACK ───────────────────────── */

function Timeline({ c }: { c: Complaint }) {
  const order: Status[] = ["pending", "in-progress", "resolved"];
  const idx = order.indexOf(c.status);
  return (
    <div className="flex items-center">
      {order.map((s, i) => (
        <div key={s} className="flex flex-1 items-center last:flex-none">
          <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: i * 0.12 }}
            className={`flex h-7 w-7 items-center justify-center rounded-full border text-xs ${i <= idx ? "border-orange-400 bg-orange-400 text-black" : "border-white/20 text-zinc-500"}`}>
            {i < idx || c.status === "resolved" ? <Check size={14} strokeWidth={3} /> : i + 1}
          </motion.div>
          {i < 2 && (
            <div className="mx-1 h-0.5 flex-1 overflow-hidden rounded bg-white/10">
              <motion.div className="h-full bg-orange-400" initial={{ width: 0 }} animate={{ width: i < idx ? "100%" : "0%" }} transition={{ duration: 0.8, delay: 0.2 + i * 0.2 }} />
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

function Card({ c, highlight, children }: { c: Complaint; highlight?: boolean; children?: React.ReactNode }) {
  return (
    <motion.div layout initial={{ opacity: 0, y: 24, scale: 0.97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} whileHover={{ y: -3 }}
      className={`glass overflow-hidden rounded-3xl ${highlight ? "ring-2 ring-orange-400/70" : ""}`}>
      <div className="flex gap-4 p-5">
        {c.photo ? <img src={c.photo} alt="" className="h-20 w-20 shrink-0 rounded-2xl object-cover" /> : (
          <div className={`flex h-20 w-20 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br text-3xl ${CATS[c.category].grad}`}>{CATS[c.category].emoji}</div>
        )}
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-mono text-xs text-zinc-500">{c.id}</span>
            <StatusBadge s={c.status} />
            <span className={`rounded-full border px-2 py-0.5 text-[11px] font-medium ${PRI[c.ai.priority]}`}>{c.ai.priority}</span>
            <span className="ml-auto text-xs text-zinc-500">{timeAgo(c.createdAt)}</span>
          </div>
          <p className="mt-1.5 line-clamp-2 text-sm text-zinc-200">{c.description}</p>
          <p className="mt-1 flex items-center gap-1 text-xs text-zinc-500"><MapPin size={12} /> {c.location} · <span className="text-orange-300/90">{CATS[c.category].label} → {c.assignee}</span></p>
        </div>
      </div>
      <div className="border-t border-white/5 bg-black/20 px-5 py-4">
        <Timeline c={c} />
        <div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-zinc-400">
          <Sparkles size={13} className="text-orange-400" /> AI: {c.ai.summary}
          {c.ai.tags.map((t) => <span key={t} className="rounded-md bg-white/5 px-1.5 py-0.5">#{t}</span>)}
        </div>
        {children}
      </div>
    </motion.div>
  );
}

function Stats({ items }: { items: Complaint[] }) {
  const n = (s: Status) => items.filter((c) => c.status === s).length;
  const data = [
    { l: "Total", v: items.length, c: "text-white" },
    { l: "Pending", v: n("pending"), c: "text-amber-300" },
    { l: "In progress", v: n("in-progress"), c: "text-sky-300" },
    { l: "Resolved", v: n("resolved"), c: "text-emerald-300" },
  ];
  return (
    <div className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
      {data.map((d, i) => (
        <motion.div key={d.l} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }} className="glass rounded-2xl p-4">
          <p className="text-xs uppercase tracking-widest text-zinc-500">{d.l}</p>
          <p className={`font-display mt-1 text-4xl font-semibold ${d.c}`}><Counter to={d.v} /></p>
        </motion.div>
      ))}
    </div>
  );
}

function Track({ items, highlight }: { items: Complaint[]; highlight: string | null }) {
  const [f, setF] = useState<Status | "all">("all");
  const list = items.filter((c) => f === "all" || c.status === f);
  return (
    <div>
      <h2 className="font-display mb-1 text-4xl font-semibold">Your complaints</h2>
      <p className="mb-6 text-zinc-400">Live status — pending, in progress or resolved.</p>
      <Stats items={items} />
      <div className="mb-5 flex flex-wrap gap-2">
        {(["all", "pending", "in-progress", "resolved"] as const).map((s) => (
          <button key={s} onClick={() => setF(s)} className={`rounded-full border px-3.5 py-1.5 text-xs font-medium capitalize transition ${f === s ? "border-orange-400 bg-orange-400 text-black" : "border-white/10 text-zinc-300 hover:bg-white/10"}`}>
            {s.replace("-", " ")}
          </button>
        ))}
      </div>
      <div className="grid gap-4">
        <AnimatePresence>{list.map((c) => <Card key={c.id} c={c} highlight={c.id === highlight} />)}</AnimatePresence>
        {!list.length && <p className="py-16 text-center text-zinc-500">Nothing here yet ✨</p>}
      </div>
    </div>
  );
}

/* ───────────────────────── STAFF ───────────────────────── */

function Staff({ items, setStatus }: { items: Complaint[]; setStatus: (id: string, s: Status) => void }) {
  const [role, setRole] = useState<Category>("infrastructure");
  const mine = useMemo(() => items.filter((c) => c.category === role), [items, role]);
  const next: Record<Status, Status | null> = { pending: "in-progress", "in-progress": "resolved", resolved: null };
  return (
    <div>
      <h2 className="font-display mb-1 text-4xl font-semibold">Staff panel</h2>
      <p className="mb-6 text-zinc-400">Each complaint lands directly with the concerned person.</p>
      <div className="relative mb-6 grid gap-2 sm:grid-cols-3">
        {(Object.keys(CATS) as Category[]).map((k) => (
          <button key={k} onClick={() => setRole(k)} className="relative rounded-2xl border border-white/10 p-4 text-left">
            {role === k && <motion.span layoutId="role" className="absolute inset-0 rounded-2xl border border-orange-400/70 bg-orange-400/10" transition={{ type: "spring", stiffness: 400, damping: 32 }} />}
            <span className="relative flex items-center gap-3">
              <span className="text-2xl">{CATS[k].emoji}</span>
              <span>
                <span className="block font-semibold">{CATS[k].staff}</span>
                <span className="block text-xs text-zinc-400">{CATS[k].label} · {items.filter((c) => c.category === k && c.status !== "resolved").length} open</span>
              </span>
            </span>
          </button>
        ))}
      </div>
      <Stats items={mine} />
      <div className="grid gap-4">
        <AnimatePresence mode="popLayout">
          {mine.map((c) => (
            <Card key={c.id} c={c}>
              <div className="mt-4 flex gap-2">
                {next[c.status] ? (
                  <motion.button whileTap={{ scale: 0.95 }} onClick={() => setStatus(c.id, next[c.status]!)} className="flex items-center gap-1.5 rounded-xl bg-orange-400 px-4 py-2 text-xs font-semibold text-black hover:bg-orange-300">
                    Mark {STATUS_META[next[c.status]!].label} <ChevronRight size={14} />
                  </motion.button>
                ) : (
                  <span className="flex items-center gap-1.5 text-xs text-emerald-300"><Check size={14} /> Closed — student notified</span>
                )}
              </div>
            </Card>
          ))}
        </AnimatePresence>
        {!mine.length && <p className="py-16 text-center text-zinc-500">No complaints for this role 🎉</p>}
      </div>
    </div>
  );
}
