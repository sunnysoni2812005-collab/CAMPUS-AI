export type Category = "discipline" | "cleanliness" | "infrastructure";
export type Status = "pending" | "in-progress" | "resolved";
export type Priority = "low" | "medium" | "high";

export interface Complaint {
  id: string;
  category: Category;
  location: string;
  description: string;
  photo?: string;
  createdAt: number;
  status: Status;
  assignee: string;
  ai: { priority: Priority; summary: string; tags: string[]; eta: string; confidence: number };
  timeline: { status: Status; at: number }[];
}

export const CATS: Record<Category, { label: string; staff: string; emoji: string; blurb: string; grad: string }> = {
  discipline: { label: "Discipline", staff: "Discipline Head", emoji: "🛡️", blurb: "Ragging, late entry, rule violations", grad: "from-rose-500/30 to-orange-500/10" },
  cleanliness: { label: "Cleanliness", staff: "Peon In-charge", emoji: "🧹", blurb: "Washrooms, garbage, dirty classrooms", grad: "from-emerald-500/30 to-teal-500/10" },
  infrastructure: { label: "Infrastructure", staff: "Director", emoji: "🏗️", blurb: "Repair, renovation, broken fixtures", grad: "from-sky-500/30 to-indigo-500/10" },
};

export const STATUS_META: Record<Status, { label: string; color: string; dot: string }> = {
  pending: { label: "Pending", color: "text-amber-300 bg-amber-400/10 border-amber-400/30", dot: "bg-amber-400" },
  "in-progress": { label: "In Progress", color: "text-sky-300 bg-sky-400/10 border-sky-400/30", dot: "bg-sky-400" },
  resolved: { label: "Resolved", color: "text-emerald-300 bg-emerald-400/10 border-emerald-400/30", dot: "bg-emerald-400" },
};

const HIGH = ["fire", "leak", "spark", "short circuit", "wire", "danger", "ragging", "fight", "harass", "flood", "collapse", "crack", "unsafe", "broken glass", "smoke", "bully"];
const MED = ["broken", "not working", "dirty", "smell", "stink", "garbage", "damaged", "late", "smoking", "noise", "blocked", "overflow", "fan", "light"];

export function analyze(category: Category, description: string, hasPhoto: boolean) {
  const d = description.toLowerCase();
  const hi = HIGH.filter((k) => d.includes(k));
  const me = MED.filter((k) => d.includes(k));
  const priority: Priority = hi.length ? "high" : me.length ? "medium" : "low";
  const clean = description.trim().replace(/\s+/g, " ");
  const first = clean.split(/[.!?\n]/)[0];
  const summary = first.length > 90 ? first.slice(0, 87) + "…" : first;
  const tags = [...new Set([...hi, ...me])].slice(0, 3);
  const eta = priority === "high" ? "within 4 hrs" : priority === "medium" ? "within 24 hrs" : "within 3 days";
  const confidence = Math.min(99, 82 + hi.length * 5 + me.length * 3 + (hasPhoto ? 4 : 0));
  return { priority, summary: summary || "No description", tags: tags.length ? tags : [CATS[category].label.toLowerCase()], eta, confidence };
}

export const timeAgo = (t: number) => {
  const s = Math.floor((Date.now() - t) / 1000);
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
};

const now = Date.now();
const mk = (id: string, category: Category, location: string, description: string, status: Status, ago: number): Complaint => ({
  id, category, location, description, status, createdAt: now - ago, assignee: CATS[category].staff,
  ai: analyze(category, description, false),
  timeline: [{ status: "pending", at: now - ago }, ...(status !== "pending" ? [{ status: "in-progress" as Status, at: now - ago / 2 }] : []), ...(status === "resolved" ? [{ status: "resolved" as Status, at: now - ago / 4 }] : [])],
});

export const SEED: Complaint[] = [
  mk("CMP-1042", "infrastructure", "Block B, Room 204", "Ceiling fan is broken and making loud noise. Wires look exposed.", "in-progress", 3600e3 * 7),
  mk("CMP-1041", "cleanliness", "Canteen washroom", "Washroom is dirty and there is a bad smell since morning.", "pending", 3600e3 * 2),
  mk("CMP-1039", "discipline", "Main gate", "Students are smoking near the gate during lunch break.", "resolved", 3600e3 * 30),
];
